package foogether.meetings.service;

import foogether.meetings.web.dto.DefaultResponse;
import foogether.meetings.web.dto.MeetingDto;

import java.util.List;

public interface MeetingService {

    // Entity List타입으로 먼저 반환받음
//    List<MeetingDto> selectAll() throws Exception;
    DefaultResponse<List<MeetingDto>> selectAll() throws Exception;

}
