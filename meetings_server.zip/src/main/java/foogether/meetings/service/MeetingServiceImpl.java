package foogether.meetings.service;

import foogether.meetings.domain.Active;
import foogether.meetings.domain.Entity.Meeting;
import foogether.meetings.repository.MeetingRepository;
import foogether.meetings.utils.ResponseMessage;
import foogether.meetings.utils.StatusCode;
import foogether.meetings.web.dto.DefaultResponse;
import foogether.meetings.web.dto.MeetingDto;
import jdk.net.SocketFlow;
import lombok.RequiredArgsConstructor;
import org.omg.PortableInterceptor.ACTIVE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@RequiredArgsConstructor    // final차입 repository 의존성 주입
@Service
public class MeetingServiceImpl implements MeetingService {

    @Autowired
    private final MeetingRepository meetingRepository;

    // 작품 전체 조회(ACTIVE 인것만)
    @Override
    public DefaultResponse<List<MeetingDto>> selectAll() throws Exception {

        // meetingList 중 객체 하나를 MeetingDto의 entity->dto 하는 생성자함수로 만들어서 List로 만들어라
        List<Meeting> meetingList = meetingRepository.findAllByActive(Active.ACTIVE);

        final int numMeeting = meetingList.size();

        return DefaultResponse.res("success", numMeeting, ResponseMessage.READ_ALL_CONTENTS,
                meetingList.stream()
                        .map(meetings -> new MeetingDto(meetings))
                        .collect(Collectors.toList()));

    }
}
