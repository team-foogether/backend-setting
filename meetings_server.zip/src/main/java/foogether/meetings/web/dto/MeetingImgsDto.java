package foogether.meetings.web.dto;

public class MeetingImgsDto {
}
