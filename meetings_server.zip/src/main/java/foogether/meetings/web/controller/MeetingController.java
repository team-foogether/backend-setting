package foogether.meetings.web.controller;

import foogether.meetings.service.MeetingService;
import foogether.meetings.utils.ResponseMessage;
import foogether.meetings.utils.StatusCode;
import foogether.meetings.web.dto.DefaultResponse;
import foogether.meetings.web.dto.MeetingDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/meetings")
@RestController
public class MeetingController {
//    private static final DefaultResponse UNAUTHORIZED_RES = new DefaultResponse("error", ResponseMessage.UNAUTHORIZED);

    @Autowired
    MeetingService meetingService;

    // TODO : Token 적용
    // @RequestHeader(value = "Authorization", required = false) final String header
    // ResponseEntity : Status 코드 상태변수와 body로 이루어져 있음
    // 모이자 전체 리스트 가져오기
    @GetMapping("/")
    public ResponseEntity selectAll(@RequestParam(value = "limit", defaultValue = "0", required = false) int limit,
                                    @RequestParam(value = "offset", defaultValue = "0", required = false) int offset)
                                    throws Exception {
        try {
            // 검색해온 meetingList == defaultResponse
            DefaultResponse<List<MeetingDto>> defaultResponse =
                    meetingService.selectAll();

            return new ResponseEntity<>(defaultResponse, HttpStatus.OK);

        } catch (Exception e) {
            DefaultResponse defaultResponse = DefaultResponse.res("fail", ResponseMessage.INTERNAL_SERVER_ERROR);
            return new ResponseEntity<>(defaultResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



//    public List<MeetingDto> findAll(@RequestParam(value = "limit", defaultValue = "", required = true) int limit,
//                                    @RequestParam(value = "offset", defaultValue = "", required = true) int offset,
//                                    @RequestBody MeetingDto meetingDto) throws Exception
}
