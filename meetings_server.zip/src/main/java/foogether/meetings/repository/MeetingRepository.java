package foogether.meetings.repository;

import foogether.meetings.domain.Active;
import foogether.meetings.domain.Entity.Meeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MeetingRepository extends JpaRepository<Meeting, Integer> {
    //    @Query("SELECT m FROM Meeting m ORDER BY m.id DESC")
    //    List<Meeting> findAllDesc();

    List<Meeting> findAllByActive(Active active);
}
