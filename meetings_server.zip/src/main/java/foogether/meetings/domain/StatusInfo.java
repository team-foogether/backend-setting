package foogether.meetings.domain;

public enum StatusInfo {
    RECRUITING, COMPLETE, FAIL
}