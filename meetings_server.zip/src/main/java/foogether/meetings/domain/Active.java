package foogether.meetings.domain;

public enum Active {
    ACTIVE, UNACTIVE
}
